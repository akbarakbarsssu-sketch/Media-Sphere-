package com.mediasphere.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MediaSphereApp() }
    }
}

private data class Feature(val emoji: String, val title: String, val subtitle: String, val tab: String)
private val features = listOf(
    Feature("🌍", "World Radio", "Discover stations by country, language and genre", "Radio"),
    Feature("📻", "FM Radio", "FM reception depends on compatible phone hardware", "Radio"),
    Feature("🎬", "Video Player", "Open local videos and supported streams", "Library"),
    Feature("🎵", "Music Player", "Browse music and build your listening queue", "Library"),
    Feature("📝", "Transcription Studio", "Prepare audio and video speech for transcription", "AI Studio"),
    Feature("💬", "Auto Captions", "Subtitle workflow with SRT/VTT export planned", "AI Studio"),
    Feature("🔎", "Online Discovery", "Search supported media providers", "Explore"),
    Feature("📂", "Offline Media Vault", "Organize files stored on your device", "Library")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MediaSphereApp() {
    var dark by remember { mutableStateOf(true) }
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    val purple = Color(0xFF9D87FF)
    val scheme = if (dark) darkColorScheme(primary = purple, secondary = Color(0xFFC1B5FF))
                 else lightColorScheme(primary = Color(0xFF6045C5), secondary = Color(0xFF7863D8))
    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            topBar = {
                TopAppBar(title = { Column {
                    Text("MediaSphere", fontWeight = FontWeight.Bold)
                    Text("Your world. Your media.", fontSize = 12.sp)
                } }, actions = {
                    Text(if (dark) "Dark" else "Light", modifier = Modifier.padding(end = 6.dp))
                    Switch(checked = dark, onCheckedChange = { dark = it }, modifier = Modifier.padding(end = 10.dp))
                })
            },
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Radio", "Library", "AI Studio", "Settings").forEach { item ->
                        NavigationBarItem(selected = tab == item, onClick = { tab = item },
                            icon = { Text(when(item) { "Home" -> "⌂"; "Radio" -> "◉"; "Library" -> "♫"; "AI Studio" -> "✦"; else -> "⚙" }, fontSize = 19.sp) },
                            label = { Text(item, fontSize = 10.sp) })
                    }
                }
            }
        ) { padding ->
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Text(if (tab == "Home") "Listen. Watch. Understand." else tab, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("A single home for music, video, radio and language tools.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text("Search features") }, placeholder = { Text("Radio, music, captions…") })
                }
                item {
                    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp)) {
                            Text("YOUR PERSONAL MEDIA HUB", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Everything in one place", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text("Explore your media and build your own offline library.")
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { tab = "AI Studio" }) { Text("Explore AI Studio") }
                        }
                    }
                }
                item { Text("Explore features", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                items(features.filter { (it.title + " " + it.subtitle).contains(query, true) && (tab == "Home" || tab == "Settings" || it.tab == tab || (tab == "Explore" && it.tab == "Explore")) }.size) { index ->
                    val list = features.filter { (it.title + " " + it.subtitle).contains(query, true) && (tab == "Home" || tab == "Settings" || it.tab == tab || (tab == "Explore" && it.tab == "Explore")) }
                    val feature = list[index]
                    Card(modifier = Modifier.fillMaxWidth().clickable { tab = feature.tab }, shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(feature.emoji, fontSize = 29.sp, modifier = Modifier.padding(end = 14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(feature.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(feature.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                            }
                            Text("›", fontSize = 26.sp)
                        }
                    }
                }
                item {
                    Spacer(Modifier.height(4.dp))
                    Text("Starter project • Media integrations are not yet connected", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
