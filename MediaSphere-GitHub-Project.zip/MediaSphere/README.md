# MediaSphere — Android starter project

MediaSphere is a Kotlin + Jetpack Compose starter for an all-in-one media studio. It includes a responsive home dashboard, feature search, bottom navigation, and dark/light theme switching. AndroidX Media3 dependencies are included as the foundation for future playback work.

## Important: current implementation status

This ZIP is a **starter source project**, not a finished media application. The UI and navigation work, but the following still require implementation and testing:

- Internet radio catalog and actual station playback
- Device-specific FM radio support (not available on every Android phone)
- Local audio/video file picker and Media3 playback screens
- Background playback service and media-session controls
- Speech-to-text engine, language detection, translation, and speaker labels
- Subtitle timing/editor and SRT/VTT export
- Authorized provider APIs for online discovery

No fake radio stations or fake AI results are included. Online streams need internet. Caching a station list does not make a live stream available offline.

## Open in Android Studio

1. Download and extract this ZIP.
2. Open Android Studio and choose **Open**; select the extracted `MediaSphere` folder.
3. Install the Android SDK platform/build tools requested by Android Studio (compile SDK 35) and use JDK 17.
4. Allow Gradle sync to finish, then press **Run** to test on an emulator or Android phone.
5. To build an APK, use **Build > Build APK(s)**. The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.

## Upload to GitHub from a phone

1. Extract the ZIP using your file manager.
2. Open your GitHub repository and choose **Add file > Upload files**.
3. Upload the *contents* of the `MediaSphere` folder (including `app`, Gradle files, and README), not just a screenshot or the ZIP itself.
4. Commit the upload. GitHub stores the source code; it does not automatically turn it into an APK.

## GitHub Actions

A workflow is included at `.github/workflows/android.yml`. It builds a debug APK when code is pushed. Download it from the workflow run's **Artifacts** section after the build succeeds.
